################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/application.c \
../app/common.c \
../app/modbus.c \
../app/modbus_communication.c \
../app/platform_specific.c 

OBJS += \
./app/application.o \
./app/common.o \
./app/modbus.o \
./app/modbus_communication.o \
./app/platform_specific.o 

C_DEPS += \
./app/application.d \
./app/common.d \
./app/modbus.d \
./app/modbus_communication.d \
./app/platform_specific.d 


# Each subdirectory must supply rules for building sources it contributes
app/%.o app/%.su app/%.cyclo: ../app/%.c app/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -DUSE_HAL_DRIVER -DSTM32G030xx -c -I../Core/Inc -I../Drivers/STM32G0xx_HAL_Driver/Inc -I../Drivers/STM32G0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-app

clean-app:
	-$(RM) ./app/application.cyclo ./app/application.d ./app/application.o ./app/application.su ./app/common.cyclo ./app/common.d ./app/common.o ./app/common.su ./app/modbus.cyclo ./app/modbus.d ./app/modbus.o ./app/modbus.su ./app/modbus_communication.cyclo ./app/modbus_communication.d ./app/modbus_communication.o ./app/modbus_communication.su ./app/platform_specific.cyclo ./app/platform_specific.d ./app/platform_specific.o ./app/platform_specific.su

.PHONY: clean-app

