################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/interface/oled/OLED.c \
../app/interface/oled/ssd1306.c \
../app/interface/oled/ssd1306_fonts.c 

OBJS += \
./app/interface/oled/OLED.o \
./app/interface/oled/ssd1306.o \
./app/interface/oled/ssd1306_fonts.o 

C_DEPS += \
./app/interface/oled/OLED.d \
./app/interface/oled/ssd1306.d \
./app/interface/oled/ssd1306_fonts.d 


# Each subdirectory must supply rules for building sources it contributes
app/interface/oled/%.o app/interface/oled/%.su app/interface/oled/%.cyclo: ../app/interface/oled/%.c app/interface/oled/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -DUSE_HAL_DRIVER -DSTM32G030xx -c -I../Core/Inc -I../Drivers/STM32G0xx_HAL_Driver/Inc -I../Drivers/STM32G0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-app-2f-interface-2f-oled

clean-app-2f-interface-2f-oled:
	-$(RM) ./app/interface/oled/OLED.cyclo ./app/interface/oled/OLED.d ./app/interface/oled/OLED.o ./app/interface/oled/OLED.su ./app/interface/oled/ssd1306.cyclo ./app/interface/oled/ssd1306.d ./app/interface/oled/ssd1306.o ./app/interface/oled/ssd1306.su ./app/interface/oled/ssd1306_fonts.cyclo ./app/interface/oled/ssd1306_fonts.d ./app/interface/oled/ssd1306_fonts.o ./app/interface/oled/ssd1306_fonts.su

.PHONY: clean-app-2f-interface-2f-oled

