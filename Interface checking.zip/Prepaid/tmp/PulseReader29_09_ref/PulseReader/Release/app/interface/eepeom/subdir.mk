################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/interface/eepeom/eeprom.c 

OBJS += \
./app/interface/eepeom/eeprom.o 

C_DEPS += \
./app/interface/eepeom/eeprom.d 


# Each subdirectory must supply rules for building sources it contributes
app/interface/eepeom/%.o app/interface/eepeom/%.su app/interface/eepeom/%.cyclo: ../app/interface/eepeom/%.c app/interface/eepeom/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -DUSE_HAL_DRIVER -DSTM32G030xx -c -I../Core/Inc -I../Drivers/STM32G0xx_HAL_Driver/Inc -I../Drivers/STM32G0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-app-2f-interface-2f-eepeom

clean-app-2f-interface-2f-eepeom:
	-$(RM) ./app/interface/eepeom/eeprom.cyclo ./app/interface/eepeom/eeprom.d ./app/interface/eepeom/eeprom.o ./app/interface/eepeom/eeprom.su

.PHONY: clean-app-2f-interface-2f-eepeom

