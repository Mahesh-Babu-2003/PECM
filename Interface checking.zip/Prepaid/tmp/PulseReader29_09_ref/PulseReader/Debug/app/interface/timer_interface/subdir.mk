################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/interface/timer_interface/time_interface.c 

OBJS += \
./app/interface/timer_interface/time_interface.o 

C_DEPS += \
./app/interface/timer_interface/time_interface.d 


# Each subdirectory must supply rules for building sources it contributes
app/interface/timer_interface/%.o app/interface/timer_interface/%.su app/interface/timer_interface/%.cyclo: ../app/interface/timer_interface/%.c app/interface/timer_interface/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G030xx -c -I../Core/Inc -I../Drivers/STM32G0xx_HAL_Driver/Inc -I../Drivers/STM32G0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G0xx/Include -I../Drivers/CMSIS/Include -I"E:/c/Pulse Reader/New folder/PulseReader/app" -I"E:/c/Pulse Reader/New folder/PulseReader/app/interface" -I"E:/c/Pulse Reader/New folder/PulseReader/app/interface/eepeom" -I"E:/c/Pulse Reader/New folder/PulseReader/app/interface/oled" -I"E:/c/Pulse Reader/New folder/PulseReader/app/interface/timer_interface" -O1 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-app-2f-interface-2f-timer_interface

clean-app-2f-interface-2f-timer_interface:
	-$(RM) ./app/interface/timer_interface/time_interface.cyclo ./app/interface/timer_interface/time_interface.d ./app/interface/timer_interface/time_interface.o ./app/interface/timer_interface/time_interface.su

.PHONY: clean-app-2f-interface-2f-timer_interface

